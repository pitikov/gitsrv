#define COUNTERPART_ENV_NAME "GIT_SSH_PULL"
#define COUNTERPART_PROGRAM_NAME "git-ssh-pull"
#define MY_PROGRAM_NAME "git-ssh-push"
#include "ssh-upload.c"
